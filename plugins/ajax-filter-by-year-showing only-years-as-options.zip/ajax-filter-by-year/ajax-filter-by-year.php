<?php
/**
 * Plugin Name:  AJAX Filter by Year
 * Description:  Filter posts by year via AJAX.
 * Version:      1.0.0
 * Plugin URI:   https://briandichiara.com
 * Author:       Briantics, Inc.
 * Author URI:   https://briantics.com
 * Text Domain:  ajax-filter-by-year
 * License:      GPLv3
 * License URI:  http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package AFBY
 */

namespace B7s\AFBY;

// Plugin constants.
define( 'AFBY_VERSION', '1.0.0' );
define( 'AFBY_PATH', plugin_dir_path( __FILE__ ) );
define( 'AFBY_URL', plugin_dir_url( __FILE__ ) );

// Load dependencies.
require_once AFBY_PATH . 'includes/main.php';
require_once AFBY_PATH . 'includes/persistent.php';
require_once AFBY_PATH . 'includes/assets.php';
require_once AFBY_PATH . 'includes/ajax.php';
require_once AFBY_PATH . 'includes/shortcodes.php';
