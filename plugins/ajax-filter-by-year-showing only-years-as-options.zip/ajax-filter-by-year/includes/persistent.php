<?php
/**
 * Remember the state of the filter.
 *
 * @package AFBY
 */

namespace B7s\AFBY\Persistent;

use function B7s\AFBY\defaults;

// Enable sessions for remembering the year.
add_action( 'init', 'B7s\AFBY\Persistent\init_session' );

/**
 * Init session if not already started.
 *
 * @since 1.0
 */
function init_session() {
	if ( headers_sent() ) {
		return;
	}

	session_start();
}

/**
 * Get the selected year for posts.
 *
 * @since 1.0
 *
 * @return int
 */
function get_selected_year( $id = null ) {
	$default_year = gmdate( 'Y' );

	if ( empty( $_COOKIE['afby_selected_year'] ) ) {
		return $default_year;
	}

	$cookie = json_decode( stripslashes( $_COOKIE['afby_selected_year'] ), true );

	if ( ! $id ) {
		$id = defaults( 'target' );
	}

	if ( empty( $cookie[ $id ] ) ) {
		return $default_year;
	}

	return intval( $cookie[ $id ] );
}

/**
 * Remember the selected year.
 *
 * @since 1.0
 *
 * @param int    $year The year.
 * @param string $id   The element ID.
 */
function set_selected_year( $year, $id = null ) {
	// Can't save if headers already sent.
	if ( headers_sent() ) {
		return;
	}

	if ( empty( $_COOKIE['afby_selected_year'] ) ) {
		$cookie = array();
	} else {
		$cookie = json_decode( $_COOKIE['afby_selected_year'], true );
	}

	if ( ! $id ) {
		$id = defaults( 'target' );
	}

	$cookie[ $id ] = intval( $year );

	setcookie( 'afby_selected_year', wp_json_encode( $cookie ), time() + MONTH_IN_SECONDS, '/', $_SERVER['HTTP_HOST'] );
}
