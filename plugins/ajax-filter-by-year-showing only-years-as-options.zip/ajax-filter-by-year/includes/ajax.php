<?php
/**
 * Ajax functionality.
 *
 * @package AFBY
 */

namespace B7s\AFBY\Ajax;

use function B7s\AFBY\defaults;
use function B7s\AFBY\fetch_posts;
use function B7s\AFBY\Persistent\set_selected_year;

// Create AJAX Actions.
add_action( 'wp_ajax_afby_fetch_posts', 'B7s\AFBY\Ajax\ajax_fetch_posts' );
add_action( 'wp_ajax_nopriv_afby_fetch_posts', 'B7s\AFBY\Ajax\ajax_fetch_posts' );

/**
 * Get posts via AJAX
 *
 * @since 1.0
 */
function ajax_fetch_posts() {
	$id        = ! empty( $_GET['display_id'] ) ? sanitize_text_field( trim( $_GET['display_id'] ) ) : defaults( 'target' );
	$year      = ! empty( $_GET['posts_year'] ) ? intval( sanitize_text_field( trim( $_GET['posts_year'] ) ) ) : get_selected_year( $id );
	$limit     = ! empty( $_GET['posts_limit'] ) ? intval( sanitize_text_field( trim( $_GET['posts_limit'] ) ) ) : defaults( 'limit' );
	$post_type = ! empty( $_GET['posts_type'] ) ? sanitize_text_field( trim( $_GET['posts_type'] ) ) : defaults( 'post_type' );

	$response = array(
		'success' => false,
		'html'    => '',
	);

	// Make sure we have all the data.
	if ( ! $id || ! $year || ! $limit ) {
		wp_send_json( $response );
	}

	set_selected_year( $year, $id );

	$response['success'] = true;
	$response['html']    = fetch_posts( $id, $year, $limit, $post_type );

	wp_send_json( $response );
}
