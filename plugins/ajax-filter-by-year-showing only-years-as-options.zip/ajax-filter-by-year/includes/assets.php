<?php
/**
 * Styles and Scripts
 *
 * @package AFBY
 */

namespace B7s\AFBY\Assets;

// Register Scripts and Styles.
add_action( 'wp_enqueue_scripts', 'B7s\AFBY\Assets\assets' );

/**
 * Register scripts and styles.
 *
 * @since 1.0
 */
function assets() {
	wp_register_style( 'afby-demo', AFBY_URL . 'assets/css/afby-demo.css', array(), AFBY_VERSION );
	wp_register_script( 'afby-main', AFBY_URL . 'assets/js/afby-main.js', array( 'jquery' ), AFBY_VERSION, true );

	wp_localize_script(
		'afby-main',
		'afbyVars',
		array(
			'fetchPostsUrl' => admin_url( 'admin-ajax.php' ) . '?action=afby_fetch_posts',
		)
	);
}
