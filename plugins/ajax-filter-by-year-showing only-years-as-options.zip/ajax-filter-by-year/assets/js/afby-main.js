/**
 * AJAX Filter by Year
 *
 * @package AFBY
 */

var AfbyMain = window.AjaxFilterByYear || {};

/**
 * Filter By Year Main Object.
 */
AfbyMain.Filter = ( function ($ ) {

	/**
	 * Init
	 *
	 * @since 1.0
	 */
	var init = function() {
		activateFilter();
	};

	/**
	 * Activate the Select menu filter
	 *
	 * @since 1.0
	 */
	var activateFilter = function() {
		$( 'select.afby-filter' ).on( 'change', function() {
			var year = $( this ).val(),
				target = $( this ).attr( 'data-target' ),
				params = 'afbyParams_' + target.replace( /\-/g, '_' );
				$target = $( '#' + target ),
				limit  = $target.attr( 'data-limit' );

			showLoader( $target );

			$.ajax( {
				url: afbyVars.fetchPostsUrl,
				data: {
					display_id: target,
					posts_year: year,
					posts_limit: limit,
					posts_type: window[ params ].postType,
				},
				type: 'GET',
				success: function( response ) {
					$target.replaceWith( response.html );
				}
			} );
		});
	};

	/**
	 * Display a loadeer.
	 *
	 * @param {Object} $parent Parent object.
	 */
	var showLoader = function( $parent ) {
		var $loader = $( '<div />' ).addClass( 'afby-loader' );
		$parent.prepend( $loader )
	};

	/**
	 * Make init method publicly accessible.
	 */
	return {
		init,
	};
} )( jQuery );

jQuery( window ).on( 'load', AfbyMain.Filter.init );