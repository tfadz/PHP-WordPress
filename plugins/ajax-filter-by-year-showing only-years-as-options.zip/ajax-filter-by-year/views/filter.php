<?php
/**
 * Year Posts Filter Dropdown
 *
 * @package AFBY
 */

?>
<select class="afby-filter" data-target="<?php echo esc_attr( $target ); ?>">
	<?php foreach ( $years as $year ) : ?>
		<option value="<?php echo esc_attr( $year ); ?>" <?php selected( $year, $selected ); ?>><?php echo esc_html( $year ); ?></option>
	<?php endforeach; ?>
</select>
