<?php
/**
 * Shortcodes.
 *
 * @package AFBY
 */

namespace B7s\AFBY\Shortcodes;

use function B7s\AFBY\defaults;
use function B7s\AFBY\get_post_years;
use function B7s\AFBY\fetch_posts;
use function B7s\AFBY\Persistent\get_selected_year;

// Create the shortcode [afby-filter].
add_shortcode( 'afby-filter', 'B7s\AFBY\Shortcodes\shortcode_filter' );

// Create a demo shortcode [afby-display].
add_shortcode( 'afby-display', 'B7s\AFBY\Shortcodes\shortcode_display' );

/**
 * Returns shortcode output for AJAX Year filter dropdown menu.
 *
 * Supported Shortcode Attributes:
 *     int    max-years Maximum number of years to display.
 *     string post-type The post type to display.
 *     string target    The target element ID to filter the posts.
 *
 * @since 1.0
 *
 * @param array  $atts      Shortcode attributes.
 * @param string $content   Inner shortcode content (unused).
 * @param string $shortcode The shortcode.
 *
 * @return string HTML content.
 */
function shortcode_filter( $atts = array(), $content = null, $shortcode = 'afby-filter' ) {
	$atts = shortcode_atts(
		array(
			'max-years' => null,
			'post-type' => defaults( 'post_type' ),
			'target'    => defaults( 'target' ),
		),
		$atts,
		$shortcode
	);

	$years    = get_post_years( $atts['post-type'], $atts['max-years'] );
	$selected = get_selected_year( $atts['target'] );
	$target   = $atts['target'];

	wp_localize_script(
		'afby-main',
		'afbyParams_' . str_replace( '-', '_', $target ),
		array(
			'postType' => $atts['post-type'],
		)
	);

	wp_enqueue_script( 'afby-main' );

	ob_start();
	require AFBY_PATH . 'views/filter.php';
	$output = ob_get_clean();

	return $output;
}

/**
 * Returns shortcode output for Posts Display.
 *
 * Supported Shortcode Attributes:
 *     string id        The ID of the wrapper element.
 *     string post-type The post type to display.
 *     int    limit     The number of posts to display.
 *
 * @since 1.0
 *
 * @param array  $atts      Shortcode attributes.
 * @param string $content   Inner shortcode content (unused).
 * @param string $shortcode The shortcode.
 *
 * @return string HTML content.
 */
function shortcode_display( $atts = array(), $content = null, $shortcode = 'afby-display' ) {
	$atts = shortcode_atts(
		array(
			'id'        => defaults( 'target' ),
			'post-type' => defaults( 'post_type' ),
			'limit'     => defaults( 'limit' ),
		),
		$atts,
		$shortcode
	);

	$year = get_selected_year( $atts['id'] );

	wp_enqueue_style( 'afby-demo' );

	return fetch_posts( $atts['id'], $year, $atts['limit'], $atts['post-type'] );
}
