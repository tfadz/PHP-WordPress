<?php
/**
 * Main plugin functionality
 *
 * @package AFBY
 */

namespace B7s\AFBY;

use function B7s\AFBY\Persistent\get_selected_year;

/**
 * Easily change all the defaults here.
 *
 * @since 1.0
 *
 * @return array
 */
function defaults( $setting = null ) {
	$defaults = array(
		'limit'     => 3,
		'post_type' => 'post',
		'target'    => 'afby-display-posts',
	);

	if ( null === $setting ) {
		return $defaults;
	}

	if ( empty( $defaults[ $setting ] ) ) {
		return false;
	}

	return $defaults[ $setting ];
}

/**
 * Get all the years where posts were published.
 *
 * @param string $post_type The post type.
 *
 * @return array
 */
function get_post_years( $post_type = null, $limit = null ) {
	global $wpdb;

	if ( ! $post_type ) {
		$post_type = \B7s\AFBY\defaults( 'post_type' );
	}

	$years   = array();
	$results = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT YEAR( post_date ) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' GROUP BY YEAR( post_date ) DESC",
			$post_type
		),
		ARRAY_N
	);

	if ( is_array( $results ) && count( $results ) > 0 ) {
		$counter = 0;
		foreach ( $results as $result ) {
			$years[] = $result[0];
			$counter++;
			if ( $limit && $counter >= $limit ) {
				break;
			}
		}
	}

	return $years;
}

/**
 * Fetch the posts HTML content.
 *
 * @since 1.0
 *
 * @param string $id    The wrapper ID.
 * @param int    $year  The year to display.
 * @param int    $limit The amount of posts to display.
 * @param string $post_type The post type.
 *
 * @return string
 */
function fetch_posts( $id = null, $year = false, $limit = null, $post_type = null ) {
	if ( ! $id ) {
		$id = defaults( 'target' );
	}

	if ( ! $year ) {
		$year = get_selected_year( $id );
	}

	if ( ! $post_type ) {
		$post_type = defaults( 'post_type' );
	}

	if ( ! $limit ) {
		$limit = defaults( 'limit' );
	}

	$query = new \WP_Query(
		array(
			'post_type'      => $post_type,
			'posts_per_page' => $limit,
			'post_status'    => 'publish',
			'year'           => $year,
		)
	);

	ob_start();
	require AFBY_PATH . 'views/display.php';
	return ob_get_clean();
}
