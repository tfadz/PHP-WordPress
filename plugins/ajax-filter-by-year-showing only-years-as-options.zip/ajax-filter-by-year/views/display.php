<?php
/**
 * Display latest posts by year.
 *
 * @package AFBY
 */

?>
<div class="afby-display" id="<?php echo esc_attr( $id ); ?>" data-limit="<?php echo esc_attr( $limit ); ?>">
	<?php if ( $query->have_posts() ) : ?>
		<?php
		while ( $query->have_posts() ) :
			$query->the_post();
			?>
			<article>
				<figure class="featured-image"><?php the_post_thumbnail(); ?></figure>
				<div class="post-date"><?php the_date( 'M d, Y' ); ?></div>
				<h2 class="post-title"><?php the_title(); ?></h2>
				<div class="post-excerpt"><?php the_excerpt(); ?></div>
			</article>
		<?php endwhile; ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No articles were found.', 'ajax-filter-by-year' ); ?></p>
	<?php endif; ?>
</div>
