# AJAX Filter by Year

This plugin allows you to filter posts by a year dropdown menu by providing 2 shortcodes. This is a custom plugin so it can be modified to meet your needs.

## Shortcodes

### [afby-filter]

Renders a dropdown menu that will change posts via ajax.

**Attributes**
- `max-years` _(int)_ Maximum number of years to display. Default: `none`
- `post-type` _(string)_ The Post type to fetch. Default: `post`
- `target` _(string)_ The target display element. Must be unique. If only using 1 instance, the default value should be fine. Default: `afby-display-posts`

### [afby-display]

Displays the posts content

**Attributes**
- `limit` _(int)_ Maximum number of posts to display. Default: `3`
- `id` _(string)_ The display element ID. Must be unique. If only using 1 instance, the default value should be fine. (see above) Default: `afby-display-posts`
- `post-type` _(string)_ The Post type to display. Default: `post` - **Important note:** This is ONLY for the initial state of the display. When the filter updates the content, the `post-type` value from the filter shortcode is used.

## Template Files

Template files are in the plugin's `views` folder. When customizing, it is important to leave the `class` and `data-` attributes intact for the wrapper element.

### filter.php

The select menu year filter.

### display.php

The template that displays the posts.

## Defaults

The default values can be easily changed in the main plugin file's `default()` function.

## Other Notes

- There is some basic css in `assets/css/demo.css` for demo purposes. Change, replace or remove if you'd like. The file is registered in `includes/assets.php` and enqueued in `includes/shortcodes.php` `shortcode_display()`.
- Persistent functionality has been added to retain the selection of the year in each instance. For example, if you change the year from 2021 to 2019, then reload the page, the year should stay as 2019 (and not reset back to 2021).
- This plugin requires no compiling, however it is recommended to optimize all assets using a minifier.
- If you have any questions or need any tweaks, feel free to reach out: brian@briantics.com
